import numpy as np  # numpy 라이브러리 (배열 연산에 사용)

class Rules:

    DIRECTIONS = [(0, 1), (1, 0), (1, 1), (1, -1)] # 가로, 세로, 대각선(오른쪽 아래), 대각선(왼쪽 아래)

    # 승리 판정
    @staticmethod
    def check_win(board, r, c): # 방금 놓은 돌(r, c)을 기준으로 승리 여부 판정

        player     = board[r, c]  # 방금 돌을 놓은 플레이어
        board_size = len(board)   # 보드 크기

        for dr, dc in Rules.DIRECTIONS: # 4방향 각각 검사
            count = 1 # 현재 위치 포함 1부터 시작

            for sign in [1, -1]: # 1 : 정방향, -1 : 역방향 
                nr, nc = r + dr * sign, c + dc * sign # 다음 탐색 위치 계산

                while (0 <= nr < board_size and  # 보드 범위 안이고 같은 플레이어의 돌이면 계속 탐색
                       0 <= nc < board_size and
                       board[nr, nc] == player):
                    count += 1          # 연속 개수 증가
                    nr    += dr * sign  # 다음 행으로 이동
                    nc    += dc * sign  # 다음 열로 이동

            if player == 1 and count == 5: # 흑돌 : 5개면 승리
                return True

            if player == 2 and count >= 5: # 백돌 : 5개 이상이면 승리
                return True

        return False # 모든 방향 검사 후 5목 없으면 False

    # 금수 판정
    @staticmethod
    def is_forbidden(board, r, c, player): # 착수 예정 위치(r, c)가 금수인지 판정

        if player != 1:
            return False

        board[r, c] = player # 실제 착수 전에 미리 검사

        if Rules.check_win(board, r, c): # 5목이 완성되는 수는 금수 해제
            board[r, c] = 0
            return False # 돌을 원상복구 후 False 반환

        forbidden = False # 금수 여부 초기값

        if Rules._is_overline(board, r, c, player): # 장목(6개 이상 연속) 금수 판정
            forbidden = True

        elif Rules._count_open_four(board, r, c, player) >= 2: # 쌍사(열린 4가 2방향 이상) 금수 판정
            forbidden = True

        elif Rules._count_real_open_three(board, r, c, player) >= 2: # 쌍삼(열린 3이 2방향 이상) 금수 판정
            forbidden = True

        board[r, c] = 0 # 가상으로 놓았던 돌 원상복구

        return forbidden # T : 착수 불가 F : 착수 가능

    # 장목 판정
    @staticmethod
    def _is_overline(board, r, c, player): # 흑돌이 6개 이상 연속되면 장목으로 금수
        board_size = len(board)  # 보드 크기

        for dr, dc in Rules.DIRECTIONS: # 방향 검사

            count = 1 # 현재 위치 포함 1부터 시작

            for sign in [1, -1]: # 양방향 탐색

                nr, nc = r + dr * sign, c + dc * sign # 다음 탐색 위치

                while (0 <= nr < board_size and # 범위 안이고 같은 돌이면 계속
                       0 <= nc < board_size and
                       board[nr, nc] == player):
                    count += 1          # 개수 증가
                    nr    += dr * sign  # 다음 위치로
                    nc    += dc * sign

            if count >= 6: # 6개 이상이면 장목
                return True
            
        return False # 모든 방향에서 6개 미만이면 False

    # 열린 3 판정
    @staticmethod
    def _count_real_open_three(board, r, c, player): # 실제 열린 3의 개수 반환, 착수하면 금수가되는 경우는 제외
        board_size = len(board)
        count      = 0  # 실제 열린 3 개수

        for dr, dc in Rules.DIRECTIONS: # 4방향 검사

            if not Rules._is_open_three( # 이 방향이 열린 3이 아니면 다음 방향으로
                    board, r, c, player, dr, dc, board_size):
                continue
            
            is_real = True # 진짜 열린 3 여부 (기본값: 진짜)

            ends = Rules._get_open_ends( # 열린 3의 양 끝 좌표 가져오기
                board, r, c, player, dr, dc, board_size)
            
            for er, ec in ends: # 양 끝 각각 검사

                if (0 <= er < board_size and # 끝이 보드 안이고 빈칸이면
                        0 <= ec < board_size and
                        board[er, ec] == 0):
                    
                    board[er, ec] = player # 가상으로 끝에 돌을 놓아봄

                    if Rules._is_overline(board, er, ec, player): # 장목이 되면 거짓 열린 3
                        is_real = False

                    elif Rules._count_open_four( # 쌍사가 되면 거짓 열린 3
                            board, er, ec, player) >= 2:
                        is_real = False

                    board[er, ec] = 0 # 가상 돌 원상복구 

            if is_real: # 진짜 열린 3이면 개수 증가
                count += 1

        return count # 실제 열린 3의 총 개수 반환, 2 이상이면 쌍삼으로 금수

    @staticmethod
    def _get_open_ends(board, r, c, player, dr, dc, board_size): # 연속된 돌의 양 끝 바깥 좌표 반환, 예) ○●●●○ 에서 양쪽 ○ 위치 반환

        ends = [] # 양 끝 좌표 저장 리스트

        for sign in [1, -1]: # 양방향 탐색

            steps  = 0 # 연속된 돌 개수

            nr, nc = r + dr * sign, c + dc * sign # 탐색 시작 위치

            while (0 <= nr < board_size and
                   0 <= nc < board_size and
                   board[nr, nc] == player): # 같은 돌이 계속되면 탐색
                steps += 1          # 돌 개수 증가
                nr    += dr * sign  # 다음 위치로
                nc    += dc * sign

            ends.append((
                r + sign * (steps + 1) * dr,
                c + sign * (steps + 1) * dc)) # 연속된 돌 끝 다음 칸 좌표 저장

        return ends # [(끝1_행, 끝1_열), (끝2_행, 끝2_열)] 반환

    @staticmethod
    def _is_open_three(board, r, c, player, dr, dc, board_size): # 한 방향에서 열린 3 패턴 판정, 세 가지 패턴 중 하나라도 맞으면 True

        for check in [
            Rules._check_open3_normal,  # ○●●●○
            Rules._check_open3_gap1,    # ○●○●●○
            Rules._check_open3_gap2     # ○●●○●○
        ]:
            if check(board, r, c, player, dr, dc, board_size): # 패턴이 맞으면 즉시 True 반환
                return True

        return False # 모든 패턴 불일치 시 False

    @staticmethod
    def _check_open3_normal(board, r, c, player, dr, dc, board_size): # 기본 열린 3 패턴 검사, 돌 3개가 연속되고 양 끝이 모두 빈칸

        stones = 1   # 현재 위치 포함
        ends   = []  # 양 끝 좌표 저장

        for sign in [1, -1]: # 양방향 탐색

            steps  = 0
            nr, nc = r + dr * sign, c + dc * sign

            while (0 <= nr < board_size and # 같은 돌이면 계속 탐색
                   0 <= nc < board_size and
                   board[nr, nc] == player):
                stones += 1          # 돌 개수 증가
                steps  += 1          # 이동 거리 증가
                nr     += dr * sign  # 다음 위치로
                nc     += dc * sign

            ends.append(( # 끝 다음 칸 좌표 저장
                r + sign * (steps + 1) * dr,
                c + sign * (steps + 1) * dc))
            
        if stones != 3: # 정확히 3개가 아니면 False, 2개나 4개면 열린 3 아님
            return False

        open_ends = sum( # 양 끝 중 빈칸인 곳 개수 계산, 보드 안이고 빈칸(0)이어야 열린 끝
            1 for er, ec in ends
            if (0 <= er < board_size and
                0 <= ec < board_size and
                board[er, ec] == 0))

        return open_ends == 2 # 양쪽 모두 열려있어야 열린 3, 한쪽이라도 막혀있으면 False

    @staticmethod
    def _check_open3_gap1(board, r, c, player, dr, dc, board_size): # 한 칸 띄운 열린 3 패턴 검사, 돌 사이에 빈칸이 있는 형태

        seq = [] # 현재 위치 기준 주변 7칸 시퀀스 저장

        for i in range(-3, 4): # -3부터 +3까지 7칸 탐색

            nr, nc = r + i * dr, c + i * dc # 탐색 위치 계산

            if 0 <= nr < board_size and 0 <= nc < board_size: # 보드 안이면 실제 값 저장
                seq.append(int(board[nr, nc]))
            else:
                seq.append(-1) # 보드 밖이면 -1 저장

        p   = player
        pat = [0, p, 0, p, p, 0] # 찾을 패턴: 빈칸, 돌, 빈칸, 돌, 돌, 빈칸

        for start in range(len(seq) - len(pat) + 1): # 시퀀스 안에서 패턴 탐색
            if seq[start:start + len(pat)] == pat:
                return True # 패턴 발견 시 True

        return False

    @staticmethod
    def _check_open3_gap2(board, r, c, player, dr, dc, board_size): # 다른 형태의 한 칸 띄운 열린 3 패턴 검사, 돌 사이에 빈칸이 있는 다른 형태

        seq = [] # 주변 7칸 시퀀스 저장

        for i in range(-3, 4):
            nr, nc = r + i * dr, c + i * dc

            if 0 <= nr < board_size and 0 <= nc < board_size:
                seq.append(int(board[nr, nc]))
            else:
                seq.append(-1)

        p   = player
        pat = [0, p, p, 0, p, 0] # 찾을 패턴: 빈칸, 돌, 돌, 빈칸, 돌, 빈칸

        for start in range(len(seq) - len(pat) + 1):
            if seq[start:start + len(pat)] == pat:
                return True

        return False

    # 열린 4 판정
    @staticmethod
    def _count_open_four(board, r, c, player): # 열린 4의 개수 반환
        board_size = len(board)
        count      = 0  # 열린 4 개수

        for dr, dc in Rules.DIRECTIONS: # 4방향 검사

            stones = 1   # 현재 위치 포함
            ends   = []  # 양 끝 좌표 저장

            for sign in [1, -1]: # 양방향 탐색

                steps  = 0
                nr, nc = r + dr * sign, c + dc * sign

                while (0 <= nr < board_size and # 같은 돌이면 계속 탐색
                       0 <= nc < board_size and
                       board[nr, nc] == player):
                    stones += 1
                    steps  += 1
                    nr     += dr * sign
                    nc     += dc * sign

                ends.append(( # 끝 다음 칸 좌표 저장
                    r + sign * (steps + 1) * dr,
                    c + sign * (steps + 1) * dc))

            if stones == 4: # 정확히 4개 연속인 경우만 검사

                open_ends = sum( # 열린 끝 개수 계산, 보드 안이고 빈칸이어야 열린 끝
                    1 for er, ec in ends
                    if (0 <= er < board_size and
                        0 <= ec < board_size and
                        board[er, ec] == 0))
                
                if open_ends >= 1: # 한쪽 이상 열려있으면 열린 4로 인정
                    count += 1

        return count # 열린 4의 총 개수 반환, 2 이상이면 쌍사(44)로 금수