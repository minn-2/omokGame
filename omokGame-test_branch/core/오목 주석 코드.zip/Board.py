import numpy as np

class Board:

    def __init__(self, board_size=15): # 보드 크기 저장
        self.board_size = board_size

        self.reset() # 게임 초기화 함수 호출

    def reset(self):
        self.board = np.zeros( # 15 * 15 배열을 0으로 채움
            (self.board_size, self.board_size), dtype=int)
        
        self.current_player = 1 # 현재 차례인 플레이어 저장(흑돌 먼저)
        
        self.is_over = False # 게임 종료 여부(F = 진행, T = 종료)
        
        self.winner = None # 승자 저장
        
        return self.get_state() # 현재 보드 상태를 반환

    def get_state(self):        # 보드 배열을 복사하고 CNN 신경망 입력 형태로 변환
        return self.board.copy()\
            .reshape(1, self.board_size, self.board_size)\
            .astype(np.float32)
    # copy : 원본 보드 보호

    def get_valid_moves(self): # 보드에서 값이 0인 위치(빈칸)를 모두 찾아 반환
        return np.argwhere(self.board == 0)

    def make_move(self, row, col):# 이미 돌이 있거나(!=0) 게임이 끝났으면 False 반환 (착수 실패)
        if self.board[row, col] != 0 or self.is_over:
            return False

        from core.Rules import Rules # Rules 클래스 불러오기(Board와 Rules가 서로 참조하는 순환 import 문제를 방지하기 위함)

        if Rules.is_forbidden( # 흑돌 금수 검사
                self.board, row, col, self.current_player):
            return False

        self.board[row, col] = self.current_player # 보드에 현재 플레이어의 돌을 놓음

        if Rules.check_win(self.board, row, col):
            self.is_over = True # 게임 종료 표시
            self.winner  = self.current_player # 현재 플레이어를 승자로 저장

        elif not np.any(self.board == 0): # 보드에 빈칸(0)이 하나도 없으면 무승부
            self.is_over = True
            self.winner  = 0

        self.current_player = 3 - self.current_player # 플레이어 교체
        
        return True