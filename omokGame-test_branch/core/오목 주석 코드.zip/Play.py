import tkinter as tk          # GUI 라이브러리
from tkinter import messagebox # 팝업 메시지 박스

from core.Board import Board
from core.Rules import Rules
from ai.engine  import Engine 

# 색상 설정
BG_COLOR    = '#FFFAE9'  
BOARD_COLOR = '#DCB468'  
LINE_COLOR  = '#8B6914'  
BLACK_COLOR = '#000000'  
WHITE_COLOR = '#FFFFFF'  

# 화면 및 보드 설정
CELL_SIZE   = 38         # 바둑판 한 칸 크기 
BOARD_SIZE  = 15         # 보드 크기
MARGIN      = 30         # 바둑판 테두리 여백
CANVAS_SIZE = CELL_SIZE * (BOARD_SIZE - 1) + MARGIN * 2 # 캔버스 전체 크기
WIN_W       = 805        # 창 가로 크기
WIN_H       = 552        # 창 세로 크기


class Play:

    def __init__(self):
        self.window = tk.Tk() # Tkinter 메인 윈도우 생성

        self.window.title('오목 게임') # 창 상단 제목 설정

        self.window.resizable(False, False) # 창 크기 고정

        self.window.configure(bg=BG_COLOR) # 창 배경색 설정

        self.mode      = None # 게임 모드 저장

        self.engine    = None # 게임 엔진 저장 (보드 상태, 착수, 승패 판정 담당)

        self.last_move = None # 마지막으로 둔 돌 위치 저장

        self.show_start_screen() # 시작 화면 표시 함수 호출

    # 시작 화면
    def show_start_screen(self):

        for w in self.window.winfo_children():
            w.destroy() # 화면 전환 시 이전 화면 내용 삭제

        self.window.geometry(f'{WIN_W}x{WIN_H}') # 창 크기 설정

        self.window.configure(bg=BG_COLOR) # 배경색 재설정

        center = tk.Frame(self.window, bg=BG_COLOR) # 중앙 정렬용 프레임 생성, 버튼과 타이틀을 담는 컨테이너

        center.place(relx=0.5, rely=0.5, anchor='center') # 프레임을 창 정중앙에 배치

        tk.Label(center,
            text='오목 게임',           # 표시할 텍스트
            font=('맑은 고딕', 36, 'bold'), # 폰트, 크기, 굵기
            bg=BG_COLOR,               # 배경색
            fg=BLACK_COLOR             # 글자색
        ).pack(pady=(0, 40)) # 타이틀 레이블 생성

        tk.Button(center, # 인간 vs 인간 버튼
            text='인간  vs  인간',          # 버튼 텍스트
            font=('맑은 고딕', 14),          # 폰트
            bg=BLACK_COLOR,                 # 버튼 배경색
            fg=BG_COLOR,                    # 버튼 글자색
            activebackground='#333333',     # 클릭 시 배경색
            activeforeground=BG_COLOR,      # 클릭 시 글자색
            width=16, height=2,             # 버튼 크기
            relief='flat',                  # 버튼 테두리 없음
            cursor='hand2',                 # 마우스 커서 손 모양
            command=self.start_human_game   # 클릭 시 실행 함수
        ).pack(pady=8)

        tk.Button(center, # 인간 vs AI 버튼
            text='인간  vs  AI',            # 버튼 텍스트
            font=('맑은 고딕', 14),          # 폰트
            bg=WHITE_COLOR,                 # 버튼 배경색
            fg=BLACK_COLOR,                 # 버튼 글자색
            activebackground='#EEEEEE',     # 클릭 시 배경색
            activeforeground=BLACK_COLOR,   # 클릭 시 글자색
            width=16, height=2,             # 버튼 크기
            relief='solid',                 # 버튼 테두리 있음
            cursor='hand2',                 # 마우스 커서 손 모양
            bd=1,                           # 테두리 두께
            command=self.start_ai_game      # 클릭 시 실행 함수
        ).pack(pady=8)

    # 게임 화면
    def show_game_screen(self):

        for w in self.window.winfo_children(): # 이전 화면 위젯 모두 제거
            w.destroy()

        self.window.geometry(f'{WIN_W}x{WIN_H}') # 창 크기 설정

        self.window.configure(bg=BG_COLOR) # 배경색 설정

        left = tk.Frame(self.window, bg=BG_COLOR) # 왼쪽 프레임 생성
        left.pack(side='left', padx=10, pady=10) # 바둑판 캔버스를 담는 컨테이너

        self.canvas = tk.Canvas(left,
            width=CANVAS_SIZE,              # 캔버스 가로 크기
            height=CANVAS_SIZE,             # 캔버스 세로 크기
            bg=BOARD_COLOR,                 # 바둑판 배경색
            highlightthickness=2,           # 테두리 두께
            highlightbackground=LINE_COLOR) # 테두리 색
        self.canvas.pack()

        self.canvas.bind('<Button-1>', self.on_click) # 캔버스 클릭 이벤트 연결

        right = tk.Frame(self.window,
            bg=BLACK_COLOR,  # 배경색
            width=240)       # 고정 너비
        right.pack(side='right', fill='y') # 창 오른쪽에 배치, 세로 전체 채움
        right.pack_propagate(False) # 자식 위젯 크기에 맞게 패널 크기 변경 방지

        tk.Label(right, # 오른쪽 패널 타이틀 레이블
            text='오목 게임',
            font=('맑은 고딕', 20, 'bold'),
            bg=BLACK_COLOR,  # 배경색
            fg=BG_COLOR,     # 글자색
            pady=20
        ).pack(fill='x')

        tk.Frame(right, bg='#444444', height=1 # 구분선
        ).pack(fill='x', padx=20)

        turn_frame = tk.Frame(right, bg=BLACK_COLOR) # 차례 표시 영역 프레임
        turn_frame.pack(pady=40)

        tk.Label(turn_frame,
            text='현재 차례',
            font=('맑은 고딕', 11),
            bg=BLACK_COLOR,
            fg='#AAAAAA'
        ).pack(pady=(0, 10))

        self.turn_label = tk.Label(turn_frame, # 현재 차례 돌 표시 레이블, self.tuen_label로 흑돌, 백돌 변경)
            text='흑돌',
            font=('맑은 고딕', 20, 'bold'),
            bg=BLACK_COLOR,
            fg=WHITE_COLOR)
        self.turn_label.pack()

        tk.Frame(right, bg='#444444', height=1 # 구분선
        ).pack(fill='x', padx=20, pady=20)

        mode_str = ('인간 vs 인간' # 현재 게임 모드
            if self.mode == 'human' else '인간 vs AI')

        tk.Label(right, # 게임 모드 표시 레이블
            text=mode_str,
            font=('맑은 고딕', 11),
            bg=BLACK_COLOR,
            fg='#AAAAAA'
        ).pack()

        tk.Button(right,
            text='처음으로',
            font=('맑은 고딕', 12),
            bg=BG_COLOR,
            fg=BLACK_COLOR,
            activebackground='#EEEEEE',
            relief='flat',
            cursor='hand2',
            pady=8, width=12,
            command=self.show_start_screen
            # 클릭 시 시작 화면으로 이동
        ).pack(side='bottom', pady=30)

        self.draw_board() # 보드 그리기 함수 호출

    # 보드 그리기
    def draw_board(self):

        self.canvas.delete('all') # 캔버스의 모든 그림 삭제

        for i in range(BOARD_SIZE): # 세로선
            self.canvas.create_line(
                MARGIN + i*CELL_SIZE, MARGIN,
                MARGIN + i*CELL_SIZE,
                MARGIN + (BOARD_SIZE-1)*CELL_SIZE,
                fill=LINE_COLOR, width=1)

            self.canvas.create_line( # 가로선
                MARGIN, MARGIN + i*CELL_SIZE,
                MARGIN + (BOARD_SIZE-1)*CELL_SIZE,
                MARGIN + i*CELL_SIZE,
                fill=LINE_COLOR, width=1)
          
        for sr in [3, 7, 11]: # 화점 그리기 (바둑판의 작은 점)
            for sc in [3, 7, 11]:
                cx = MARGIN + sc*CELL_SIZE
                cy = MARGIN + sr*CELL_SIZE
                self.canvas.create_oval(
                    cx-4, cy-4, cx+4, cy+4,
                    fill=LINE_COLOR, outline='')

        if (self.engine.current_player == 1 # 금수 위치에 빨간 X 표시
                and not self.engine.is_over):
            for i in range(BOARD_SIZE):
                for j in range(BOARD_SIZE):
                    if (self.engine.board.board[i][j] == 0 # 빈 칸(==0)이고 금수인 위치에 X 그리기
                            and Rules.is_forbidden(
                                self.engine.board.board,
                                i, j, 1)):
                        cx = MARGIN + j*CELL_SIZE
                        cy = MARGIN + i*CELL_SIZE
                        self.canvas.create_line(
                            cx-7, cy-7, cx+7, cy+7,
                            fill='red', width=2)
                        self.canvas.create_line(
                            cx+7, cy-7, cx-7, cy+7,
                            fill='red', width=2)

        for i in range(BOARD_SIZE): # 각 칸의 중심 픽셀 좌표 계산
            for j in range(BOARD_SIZE):
                cx = MARGIN + j*CELL_SIZE
                cy = MARGIN + i*CELL_SIZE
                
                if self.engine.board.board[i][j] == 1: # 흑돌 그리기 
                    self.canvas.create_oval(
                        cx-16, cy-16, cx+16, cy+16,
                        fill='black', outline='black')
                    
                elif self.engine.board.board[i][j] == 2: # 백돌 그리기
                    self.canvas.create_oval(
                        cx-16, cy-16, cx+16, cy+16,
                        fill='white', outline='black', width=2)
                    
        if self.last_move:
            li, lj = self.last_move # 마지막 착수 위치의 행(li), 열(lj) 추출
            cx = MARGIN + lj*CELL_SIZE
            cy = MARGIN + li*CELL_SIZE # 픽셀 좌표 계산
            self.canvas.create_oval( # 마지막 착수 위치에 빨간 점 표시
                cx-5, cy-5, cx+5, cy+5,
                fill='red', outline='')

        self.update_turn_display() # 차례 텍스트 업데이트 함수 호출

    # 차례 텍스트 업데이트
    def update_turn_display(self):

        if self.engine.is_over: # 게임이 끝났으면 차례 표시 변경 안 함
            return

        if self.engine.current_player == 1: # 현재 플레이어에 따라 텍스트 변경
            self.turn_label.config(text='흑돌')
        else:
            self.turn_label.config(text='백돌')

    # 클릭 이벤트
    def on_click(self, event):

        if self.engine.is_over: # 게임이 끝났으면 클릭 무시
            return

        j = round((event.x - MARGIN) / CELL_SIZE) # 클릭한 픽셀 좌표를 보드 좌표로 변환
        i = round((event.y - MARGIN) / CELL_SIZE)
        # MARGIN 빼고 CELL_SIZE로 나눠서 교점 계산
        # round() : 가장 가까운 교점으로 반올림

        if not (0 <= i < BOARD_SIZE and 0 <= j < BOARD_SIZE): # 보드 범위 밖을 클릭하면 무시
            return
        
        if self.engine.make_move(i, j): # 착수 성공 시 마지막 수 저장
            self.last_move = (i, j)
            self.draw_board() # 보드 전체 다시 그리기
            self.check_game_over() # 게임 종료 여부 확인

    # 게임 종료 확인
    def check_game_over(self):

        if not self.engine.is_over: # 게임이 안 끝났으면 종료
            return
        
        if self.engine.winner == 1:
            msg = '흑돌 승리!'
        elif self.engine.winner == 2:
            msg = '백돌 승리!'
        else:
            msg = '무승부!'

        self.turn_label.config(text=msg) # 오른쪽 패널 차례 표시를 결과 메시지로 변경

        messagebox.showinfo('게임 종료', msg) # 팝업 메시지 박스 표시

        self.show_start_screen() # 시작 화면으로 이동

    # 게임 시작
    def start_human_game(self):
        self.mode      = 'human'

        self.engine    = Engine(BOARD_SIZE)

        self.last_move = None # 마지막 수 초기화

        self.show_game_screen() # 게임 화면으로 전환

    def start_ai_game(self):
        messagebox.showinfo('안내', '추후 구현 예정입니다!')

    # 실행
    def run(self):
        self.window.mainloop()