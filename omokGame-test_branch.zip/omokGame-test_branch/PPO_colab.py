import json
import argparse
from datetime import datetime
from pathlib import Path

import torch
import numpy as np
import random

from ai.engine import Engine
from ai.agent  import HybridAgent
from core.Rules import Rules

# ── 경로
CKPT_DIR   = Path('checkpoints')
P2_PATH    = CKPT_DIR / 'ppo_p2.pt'
LOG_PATH   = CKPT_DIR / 'train_log.json'
KAGGLE_OUT = Path('/kaggle/working')

# ── 학습 설정
BOARD_SIZE       = 15
TOTAL_EPISODES   = 150000
SAVE_EVERY       = 200
DRIVE_SAVE_EVERY = 1000
EVAL_EVERY       = 500
EVAL_GAMES       = 40
PROMOTE_WIN_RATE = 0.57

# ── 커리큘럼 단계 설정
CURRICULUM = [
    {'name': 'random',   'episodes': 5000,   'opponent': 'random'},
    {'name': 'weak',     'episodes': 15000,  'opponent': 'weak'},
    {'name': 'strong',   'episodes': 30000,  'opponent': 'strong'},
    {'name': 'selfplay', 'episodes': 999999, 'opponent': 'self'},
]


# ──────────────────────────────────────────
# 규칙 기반 상대 에이전트
# ──────────────────────────────────────────

DIRS = [(0, 1), (1, 0), (1, 1), (1, -1)]


def get_candidates(board, radius=2):
    n        = len(board)
    occupied = np.argwhere(board != 0)
    cands    = set()
    if len(occupied) == 0:
        center = n // 2
        return [(center, center)]
    for or_, oc in occupied:
        for dr in range(-radius, radius + 1):
            for dc in range(-radius, radius + 1):
                nr, nc = or_ + dr, oc + dc
                if 0 <= nr < n and 0 <= nc < n and board[nr, nc] == 0:
                    cands.add((nr, nc))
    return list(cands)


def check_win_rule(board, r, c, player):
    n = len(board)
    for dr, dc in DIRS:
        cnt = 1
        for sign in [1, -1]:
            nr, nc = r + dr * sign, c + dc * sign
            while 0 <= nr < n and 0 <= nc < n and board[nr, nc] == player:
                cnt += 1; nr += dr * sign; nc += dc * sign
        if cnt >= 5:
            return True
    return False


def count_consec(board, r, c, player, dr, dc):
    n = len(board); count = 1; ends = 0
    for sign in [1, -1]:
        nr, nc = r + dr * sign, c + dc * sign
        while 0 <= nr < n and 0 <= nc < n and board[nr, nc] == player:
            count += 1; nr += dr * sign; nc += dc * sign
        if 0 <= nr < n and 0 <= nc < n and board[nr, nc] == 0:
            ends += 1
    return count, ends


def rule_score(board, r, c, player):
    opp = 3 - player
    board[r, c] = player
    atk = 0
    for dr, dc in DIRS:
        cnt, ends = count_consec(board, r, c, player, dr, dc)
        if cnt >= 5:                  atk += 100000
        elif cnt == 4 and ends >= 1:  atk += 50000
        elif cnt == 3 and ends == 2:  atk += 3000
    board[r, c] = 0

    board[r, c] = opp
    dfn = 0
    for dr, dc in DIRS:
        cnt, ends = count_consec(board, r, c, opp, dr, dc)
        if cnt >= 5:                  dfn += 90000
        elif cnt == 4 and ends >= 1:  dfn += 40000
        elif cnt == 3 and ends == 2:  dfn += 1000
    board[r, c] = 0
    return atk + dfn


class RandomAgent:
    """완전 랜덤 착수."""
    def decide_next_move(self, engine):
        empty = np.argwhere(engine.board.board == 0)
        if len(empty) == 0:
            return None
        idx = random.randint(0, len(empty) - 1)
        return tuple(empty[idx])


class WeakRuleAgent:
    """즉시 승리/방어만 처리하고 나머지는 랜덤."""
    def decide_next_move(self, engine):
        board  = engine.board.board
        player = engine.current_player
        opp    = 3 - player
        cands  = get_candidates(board, radius=2)
        if not cands:
            return None

        for r, c in cands:
            board[r, c] = player
            win = check_win_rule(board, r, c, player)
            board[r, c] = 0
            if win:
                return (r, c)

        for r, c in cands:
            board[r, c] = opp
            win = check_win_rule(board, r, c, opp)
            board[r, c] = 0
            if win:
                return (r, c)

        return random.choice(cands)


class StrongRuleAgent:
    """전체 heuristic scoring으로 최선의 수 선택."""
    def decide_next_move(self, engine):
        board  = engine.board.board
        player = engine.current_player
        cands  = get_candidates(board, radius=2)
        if not cands:
            return None

        best_score = -1
        best_move  = cands[0]
        for r, c in cands:
            s = rule_score(board, r, c, player)
            if s > best_score:
                best_score = s
                best_move  = (r, c)
        return best_move


class AggressiveRuleAgent:
    """공격 가중치를 높인 규칙 기반 상대."""
    def decide_next_move(self, engine):
        board = engine.board.board
        player = engine.current_player
        cands = get_candidates(board, radius=2)
        if not cands:
            return None
        best_score = -1
        best_move = cands[0]
        for r, c in cands:
            s = rule_score(board, r, c, player)
            center_bias = 5 - (abs(r - BOARD_SIZE // 2) + abs(c - BOARD_SIZE // 2))
            s = int(s * 1.25) + max(center_bias, 0) * 60
            if s > best_score:
                best_score = s
                best_move = (r, c)
        return best_move


class DefensiveRuleAgent:
    """방어 우선 규칙 기반 상대."""
    def decide_next_move(self, engine):
        board = engine.board.board
        player = engine.current_player
        opp = 3 - player
        cands = get_candidates(board, radius=2)
        if not cands:
            return None
        best_score = -1
        best_move = cands[0]
        for r, c in cands:
            board[r, c] = opp
            block_score = 0
            for dr, dc in DIRS:
                cnt, ends = count_consec(board, r, c, opp, dr, dc)
                if cnt >= 5:
                    block_score += 120000
                elif cnt == 4 and ends >= 1:
                    block_score += 70000
                elif cnt == 3 and ends == 2:
                    block_score += 6000
            board[r, c] = 0
            s = rule_score(board, r, c, player) + block_score
            if s > best_score:
                best_score = s
                best_move = (r, c)
        return best_move


# ──────────────────────────────────────────
# 파일 유틸
# ──────────────────────────────────────────

def ensure_dirs():
    CKPT_DIR.mkdir(parents=True, exist_ok=True)


def save_champion(agent, episode=0):
    ensure_dirs()
    torch.save({
        'net'      : agent.net.state_dict(),
        'optimizer': agent.optimizer.state_dict(),
        'episode'  : episode,
    }, P2_PATH)
    print(f'  [♛] 저장 완료 (ep {episode:,})')


def save_to_output(episode):
    import shutil
    if KAGGLE_OUT.exists():
        try:
            for p in [P2_PATH, LOG_PATH]:
                if p.exists():
                    shutil.copy(p, KAGGLE_OUT / p.name)
            print(f'  [OUTPUT] 백업 완료 (ep {episode:,})')
        except Exception as e:
            print(f'  [OUTPUT] 실패: {e}')


def load_champion(agent):
    if P2_PATH.exists():
        ckpt = torch.load(P2_PATH, map_location=agent.device)
        agent.net.load_state_dict(ckpt['net'])
        agent.old_net.load_state_dict(ckpt['net'])
        agent.optimizer.load_state_dict(ckpt['optimizer'])
        ep = ckpt.get('episode', 0)
        print(f'  [LOAD] ← {P2_PATH} (ep {ep:,})')
        return ep
    print(f'  [SKIP] {P2_PATH} 없음')
    return 0


def load_log():
    if LOG_PATH.exists():
        with open(LOG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        'meta'    : {'board_size': BOARD_SIZE, 'mode': 'Curriculum+SelfPlay'},
        'episodes': [],
        'summary' : {
            'total_episodes': 0, 'challenger_wins': 0,
            'champion_wins' : 0, 'draws': 0, 'champion_updates': 0,
        },
    }


def append_log(log, record):
    log['episodes'].append(record)
    s = log['summary']
    s['total_episodes'] += 1
    w = record.get('challenger_won')
    if w is True:    s['challenger_wins'] += 1
    elif w is False: s['champion_wins']   += 1
    else:            s['draws']           += 1
    if record.get('champion_updated'):
        s['champion_updates'] += 1


def save_log(log):
    ensure_dirs()
    with open(LOG_PATH, 'w', encoding='utf-8') as f:
        json.dump(log, f, ensure_ascii=False, indent=2)


# ──────────────────────────────────────────
# 보상 함수
# ──────────────────────────────────────────

def shaped_reward(engine, player):
    """
    종료 시  : 승리 +50 / 패배 -50 / 무승부 0
    진행 중  : 패턴 기반 중간 보상 (스텝당 누적 과다를 막기 위해 작게 유지)
    """
    board = engine.board.board
    opp   = 3 - player
    if engine.is_over:
        if engine.winner == player: return  50.0
        if engine.winner == opp:    return -50.0
        return 0.0

    r = 0.0
    if Rules.check_patterns(board, player, 4): r += 8.0
    if Rules.check_patterns(board, opp,    4): r -= 15.0
    if Rules.check_patterns(board, player, 3): r += 3.0
    if Rules.check_patterns(board, opp,    3): r -= 5.0
    return float(r)


# ──────────────────────────────────────────
# Champion 평가
# ──────────────────────────────────────────

def evaluate(challenger, champ_weights, n_games=EVAL_GAMES):
    assert n_games % 2 == 0
    half  = n_games // 2
    champ = challenger.make_champion_agent(champ_weights)

    black_wins = white_wins = 0
    for g in range(n_games):
        env      = Engine(BOARD_SIZE)
        env.reset()
        ch_color = 1 if g < half else 2
        agents   = {ch_color: challenger, 3 - ch_color: champ}

        while not env.is_over:
            cur  = env.current_player
            move = agents[cur]._ppo_only_move(env)
            if move is None:
                break
            env.make_move(*move)

        if env.winner == ch_color:
            if ch_color == 1: black_wins += 1
            else:             white_wins += 1

    challenger.memory.clear()
    return {
        'total': (black_wins + white_wins) / n_games,
        'black': black_wins / half,
        'white': white_wins / half,
    }


def evaluate_rule_benchmark(challenger, n_games_each=20):
    """인간전에 가까운 외부 상대풀 기준 승률."""
    opponents = [
        ('weak', WeakRuleAgent()),
        ('strong', StrongRuleAgent()),
        ('aggro', AggressiveRuleAgent()),
        ('def', DefensiveRuleAgent()),
    ]
    total_games = 0
    total_wins = 0
    detail = {}
    for name, opp_agent in opponents:
        wins = 0
        half = n_games_each // 2
        for g in range(n_games_each):
            env = Engine(BOARD_SIZE)
            env.reset()
            ch_color = 1 if g < half else 2
            agents = {ch_color: challenger, 3 - ch_color: opp_agent}
            while not env.is_over:
                cur = env.current_player
                if cur == ch_color:
                    move = challenger._ppo_only_move(env)
                else:
                    move = opp_agent.decide_next_move(env)
                if move is None:
                    break
                env.make_move(*move)
            if env.winner == ch_color:
                wins += 1
        wr = wins / max(n_games_each, 1)
        detail[name] = wr
        total_games += n_games_each
        total_wins += wins
    challenger.memory.clear()
    return {
        'total': total_wins / max(total_games, 1),
        'detail': detail,
    }


# ──────────────────────────────────────────
# 터미널 출력
# ──────────────────────────────────────────

def print_stats(ep, stats, stage_name, eval_result=None):
    bar_len  = 30
    progress = int(ep / TOTAL_EPISODES * bar_len)
    bar      = '█' * progress + '░' * (bar_len - progress)
    chw  = stats['challenger_wins']
    cpw  = stats['champion_wins']
    drw  = stats['draws']
    tot  = max(chw + cpw + drw, 1)
    loss = stats.get('loss')

    print(f'\n{"─"*58}')
    print(f'  [{stage_name}] 에피소드 {ep:>7,} / {TOTAL_EPISODES:,}')
    print(f'  [{bar}] {ep / TOTAL_EPISODES * 100:.1f}%')
    if isinstance(loss, float):
        print(f'  스텝: {stats["steps"]:,}  보상: {stats["ep_reward"]:+.2f}  Loss: {loss:.6f}')
    else:
        print(f'  스텝: {stats["steps"]:,}  보상: {stats["ep_reward"]:+.2f}  Loss: —')
    print(f'  승패  Ch {chw:,}({chw/tot*100:.1f}%)'
          f'  Champ {cpw:,}({cpw/tot*100:.1f}%)'
          f'  무 {drw:,}({drw/tot*100:.1f}%)')

    if eval_result:
        tag = '♛ CHAMPION 갱신!' if stats.get('champion_updated') else '─ 유지'
        print(f'  ┌ 평가 [{tag}]')
        print(f'  │  전체: {eval_result["total"]*100:.1f}%'
              f'  흑: {eval_result["black"]*100:.1f}%'
              f'  백: {eval_result["white"]*100:.1f}%')
        print(f'  └  역대 최고: {stats["best_eval_wr"]*100:.1f}%'
              f'  총 갱신: {stats["champion_updates"]}회')
    print(f'{"─"*58}')


# ──────────────────────────────────────────
# 메인 학습 루프
# ──────────────────────────────────────────

def run_episode(env, challenger, opp_agent, ch_color):
    """
    한 에피소드를 진행하고 (ep_reward, step, winner) 를 반환한다.

    [버그 수정]
    상대 착수로 게임이 끝난 경우(challenger 패배),
    store_reward 를 새로 호출하는 대신 마지막 저장된 보상에 패배 보상을 합산한다.
    → memory.states / memory.rewards 길이가 항상 일치하게 된다.
    """
    env.reset()
    challenger.memory.clear()

    ep_reward = 0.0
    step      = 0
    agents    = {ch_color: challenger, 3 - ch_color: opp_agent}

    while not env.is_over:
        cur   = env.current_player
        agent = agents[cur]

        if cur == ch_color:
            move = challenger._ppo_only_move(env)
        else:
            move = agent.decide_next_move(env)

        if move is None:
            break

        env.make_move(*move)
        step += 1

        if cur == ch_color:
            # challenger 착수 후 보상 저장 (done 플래그 포함)
            r = shaped_reward(env, ch_color)
            ep_reward += r
            challenger.store_reward(r, done=env.is_over)

        elif env.is_over:
            # ── [핵심 수정] 상대 착수로 게임 종료(challenger 패배) ──
            # 새 store_reward 호출 대신, 마지막 저장된 보상에 패배 보상을 합산하고
            # done 플래그를 True 로 교정한다.
            # 이렇게 하면 states/rewards 길이가 항상 같아진다.
            if len(challenger.memory.rewards) > 0:
                extra = shaped_reward(env, ch_color)   # -50.0
                challenger.memory.rewards[-1] += extra
                challenger.memory.dones[-1]    = True
                ep_reward += extra

    return ep_reward, step, env.winner


def train(resume=False):
    ensure_dirs()

    challenger = HybridAgent(BOARD_SIZE, player=2)

    start_ep = 0
    if resume:
        start_ep = load_champion(challenger)

    if not P2_PATH.exists():
        save_champion(challenger, episode=0)

    champ_weights = challenger.clone_weights()
    log           = load_log()
    summ          = log['summary']
    best_eval_wr  = 0.0

    stats = {
        'episode'         : start_ep,
        'steps'           : 0,
        'challenger_wins' : summ['challenger_wins'],
        'champion_wins'   : summ['champion_wins'],
        'draws'           : summ['draws'],
        'ep_reward'       : 0.0,
        'loss'            : None,
        'best_eval_wr'    : 0.0,
        'champion_updated': False,
        'champion_updates': summ['champion_updates'],
    }

    # ── 현재 커리큘럼 단계 결정
    def get_stage(ep):
        cumul = 0
        for stage in CURRICULUM:
            cumul += stage['episodes']
            if ep < cumul:
                return stage
        return CURRICULUM[-1]

    # ── 고정 상대 에이전트
    random_agent = RandomAgent()
    weak_agent   = WeakRuleAgent()
    strong_agent = StrongRuleAgent()
    aggro_agent  = AggressiveRuleAgent()
    def_agent    = DefensiveRuleAgent()

    def get_opponent(stage_name):
        if stage_name == 'random': return random_agent
        if stage_name == 'weak':   return weak_agent
        if stage_name == 'strong': return strong_agent
        # self-play 단계에서는 챔피언 + 규칙 기반 풀을 섞어서
        # 특정 플레이 스타일 과적합을 줄인다.
        roll = random.random()
        if roll < 0.65:
            return challenger.make_champion_agent(champ_weights)
        if roll < 0.78:
            return strong_agent
        if roll < 0.88:
            return aggro_agent
        if roll < 0.97:
            return def_agent
        return weak_agent

    print(f'\n[TRAIN] 커리큘럼 + Self-Play PPO 시작')
    print(f'  장치: {challenger.device}')
    print(f'  시작 에피소드: {start_ep + 1:,}')
    print(f'\n  커리큘럼 단계:')
    cumul = 0
    for s in CURRICULUM:
        cumul += s['episodes']
        print(f'    {s["name"]:10} → ep {cumul:,}까지')

    last_eval  = None
    last_stage = None

    for ep in range(start_ep + 1, TOTAL_EPISODES + 1):
        stage      = get_stage(ep)
        stage_name = stage['name']

        # 단계 전환 알림
        if stage_name != last_stage:
            print(f'\n{"="*58}')
            print(f'  [단계 전환] {last_stage} → {stage_name}')
            print(f'{"="*58}')
            last_stage = stage_name

        # challenger 색상 교대
        ch_color    = 1 if ep % 2 == 1 else 2
        champ_color = 3 - ch_color

        opp_agent = get_opponent(stage_name)

        env = Engine(BOARD_SIZE)
        champion_updated = False

        # ── 한 판 진행 (수정된 run_episode 사용)
        ep_reward, step, winner = run_episode(env, challenger, opp_agent, ch_color)

        # ── 승패 집계
        if winner == ch_color:
            challenger_won = True;  summ['challenger_wins'] += 1
        elif winner == champ_color:
            challenger_won = False; summ['champion_wins']   += 1
        else:
            challenger_won = None;  summ['draws']           += 1

        # ── Champion 평가 (self-play 단계에서만)
        if ep % EVAL_EVERY == 0 and stage_name == 'selfplay':
            print(f'\n[EVAL] ep {ep:,} — {EVAL_GAMES}판...')
            wr        = evaluate(challenger, champ_weights, EVAL_GAMES)
            last_eval = wr
            benchmark = evaluate_rule_benchmark(challenger, n_games_each=20)
            print(f'  전체: {wr["total"]*100:.1f}%'
                  f'  흑: {wr["black"]*100:.1f}%'
                  f'  백: {wr["white"]*100:.1f}%')
            print(f'  룰봇 풀 승률: {benchmark["total"]*100:.1f}%'
                  f'  (weak {benchmark["detail"]["weak"]*100:.1f}%'
                  f', strong {benchmark["detail"]["strong"]*100:.1f}%'
                  f', aggro {benchmark["detail"]["aggro"]*100:.1f}%'
                  f', def {benchmark["detail"]["def"]*100:.1f}%)')

            # 챔피언 승률 + 룰봇 풀 승률을 함께 통과해야 승급
            promote_ok = (
                wr['total'] >= PROMOTE_WIN_RATE
                and benchmark['total'] >= 0.60
                and benchmark['detail']['strong'] >= 0.50
            )
            if promote_ok and wr['total'] > best_eval_wr:
                best_eval_wr     = wr['total']
                save_champion(challenger, episode=ep)
                save_to_output(ep)
                champ_weights    = challenger.clone_weights()
                champion_updated = True
                stats['champion_updates'] += 1
                summ['champion_updates']  += 1
                print(f'  [♛] Champion 갱신! (총 {summ["champion_updates"]}회)')
            else:
                print(f'  [─] 유지 (역대 최고: {best_eval_wr*100:.1f}%)')

            stats['best_eval_wr']     = best_eval_wr
            stats['champion_updated'] = champion_updated

        # ── 정기 저장
        if ep % SAVE_EVERY == 0:
            save_champion(challenger, episode=ep)
            save_log(log)

        if ep % DRIVE_SAVE_EVERY == 0:
            save_to_output(ep)
            save_log(log)

        # ── 로그
        record = {
            'episode'         : ep,
            'stage'           : stage_name,
            'ch_color'        : ch_color,
            'winner'          : int(winner) if winner is not None else 0,
            'challenger_won'  : challenger_won,
            'steps'           : step,
            'ep_reward'       : round(ep_reward, 4),
            'loss'            : challenger.last_loss,
            'champion_updated': champion_updated,
            'timestamp'       : datetime.now().isoformat(timespec='seconds'),
        }
        append_log(log, record)

        stats.update({
            'episode'        : ep,
            'steps'          : step,
            'ep_reward'      : ep_reward,
            'challenger_wins': summ['challenger_wins'],
            'champion_wins'  : summ['champion_wins'],
            'draws'          : summ['draws'],
            'loss'           : challenger.last_loss,
        })

        if ep % 100 == 0:
            print_stats(ep, stats, stage_name,
                        last_eval if ep % EVAL_EVERY == 0 else None)
            last_eval = None

    save_champion(challenger, episode=ep)
    save_to_output(ep)
    save_log(log)
    print('\n[DONE] 학습 종료')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--resume', action='store_true',
                        help='checkpoints/ppo_p2.pt 에서 이어서 학습')
    args = parser.parse_args()
    train(resume=args.resume)