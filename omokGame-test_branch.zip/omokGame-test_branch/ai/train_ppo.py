import numpy as np
from ai.agent import get_candidates, count_consecutive, rule_score, DIRS

BOARD_SIZE = 15
INF        = float('inf')


def heuristic_eval(board: np.ndarray, player: int) -> float:
    opp   = 3 - player
    score = 0.0
    n     = len(board)

    score_table = {
        (5, 2): 100000, (5, 1): 100000, (5, 0): 100000,
        (4, 2): 10000,  (4, 1): 5000,
        (3, 2): 1000,   (3, 1): 200,
        (2, 2): 100,    (2, 1): 20,
    }

    for r in range(n):
        for c in range(n):
            if board[r,c] == player:
                for dr, dc in DIRS:
                    cnt, ends = count_consecutive(board, r, c, player, dr, dc)
                    key = (min(cnt,5), ends)
                    score += score_table.get(key, 0)
            elif board[r,c] == opp:
                for dr, dc in DIRS:
                    cnt, ends = count_consecutive(board, r, c, opp, dr, dc)
                    key = (min(cnt,5), ends)
                    score -= score_table.get(key, 0) * 1.1  # 방어 가중치

    return score


def check_win(board: np.ndarray, r: int, c: int, player: int) -> bool:
    n = len(board)
    for dr, dc in DIRS:
        cnt = 1
        for sign in [1,-1]:
            nr, nc = r+dr*sign, c+dc*sign
            while 0<=nr<n and 0<=nc<n and board[nr,nc]==player:
                cnt+=1; nr+=dr*sign; nc+=dc*sign
        if cnt >= 5:
            return True
    return False


def minimax(board: np.ndarray, depth: int, alpha: float, beta: float,
            maximizing: bool, player: int, last_move: tuple) -> float:
    opp = 3 - player

    # 종료 조건: 이전 수로 게임 종료
    if last_move is not None:
        r, c       = last_move
        last_player = board[r,c]
        if check_win(board, r, c, last_player):
            return 100000.0 if last_player == player else -100000.0

    if depth == 0 or not np.any(board == 0):
        return heuristic_eval(board, player)

    # 후보 생성 (반경 2칸)
    candidates = get_candidates(board, radius=2)
    if not candidates:
        return heuristic_eval(board, player)

    # 후보 정렬 (빠른 가지치기용)
    cur_player = player if maximizing else opp
    candidates.sort(
    key=lambda m: rule_score(board, m[0], m[1], cur_player),
    reverse=True
    )
    candidates = candidates[:8]   # 상위 8개만 탐색

    if maximizing:
        best = -INF
        for r, c in candidates:
            board[r,c] = player
            val        = minimax(board, depth-1, alpha, beta, False, player, (r,c))
            board[r,c] = 0
            best       = max(best, val)
            alpha      = max(alpha, best)
            if beta <= alpha:
                break   # Beta cut-off
        return best
    else:
        best = INF
        for r, c in candidates:
            board[r,c] = opp
            val        = minimax(board, depth-1, alpha, beta, True, player, (r,c))
            board[r,c] = 0
            best       = min(best, val)
            beta       = min(beta, best)
            if beta <= alpha:
                break   # Alpha cut-off
        return best


def search_best_move(board: np.ndarray, player: int,
                     top_k_candidates: list, depth: int = 2) -> tuple:
    if not top_k_candidates:
        candidates = get_candidates(board, radius=2)
        top_k_candidates = candidates[:10]

    best_score = -INF
    best_move  = top_k_candidates[0]

    for r, c in top_k_candidates:
        if board[r,c] != 0:
            continue
        board[r,c] = player
        score      = minimax(board, depth-1, -INF, INF, False, player, (r,c))
        board[r,c] = 0

        if score > best_score:
            best_score = score
            best_move  = (r, c)

    return best_move