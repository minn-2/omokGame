import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical
from pathlib import Path

from core.Rules import Rules
from ai.model import PPOModel

# ──────────────────────────────────────────
# 점수 상수 (Rule Engine)
# ──────────────────────────────────────────
SCORE_WIN          = 100000
SCORE_BLOCK_WIN    =  90000
SCORE_OPEN_FOUR    =  50000
SCORE_BLOCK_FOUR   =  40000
SCORE_OPEN_THREE   =   3000
SCORE_BLOCK_THREE  =   1000
SCORE_CENTER       =     50
SCORE_CONNECT      =     10

DIRS = [(0,1),(1,0),(1,1),(1,-1)]

# ──────────────────────────────────────────
# Rule Engine 유틸
# ──────────────────────────────────────────

def get_candidates(board: np.ndarray, radius: int = 2) -> list:
    """기존 돌 주변 radius 칸 이내 빈 칸만 후보로 반환."""
    n        = len(board)
    occupied = np.argwhere(board != 0)
    cands    = set()

    if len(occupied) == 0:
        center = n // 2
        return [(center, center)]

    for or_, oc in occupied:
        for dr in range(-radius, radius+1):
            for dc in range(-radius, radius+1):
                nr, nc = or_+dr, oc+dc
                if 0<=nr<n and 0<=nc<n and board[nr,nc]==0:
                    cands.add((nr, nc))

    return list(cands)


def count_consecutive(board, r, c, player, dr, dc):
    n     = len(board)
    count = 1
    ends  = 0

    for sign in [1, -1]:
        nr, nc = r+dr*sign, c+dc*sign
        while 0<=nr<n and 0<=nc<n and board[nr,nc]==player:
            count+=1; nr+=dr*sign; nc+=dc*sign
        if 0<=nr<n and 0<=nc<n and board[nr,nc]==0:
            ends += 1

    return count, ends


def check_win(board, r, c, player):
    """(r,c)에서 player가 승리했는지 확인."""
    n = len(board)
    for dr, dc in DIRS:
        cnt = 1
        for sign in [1,-1]:
            nr, nc = r+dr*sign, c+dc*sign
            while 0<=nr<n and 0<=nc<n and board[nr,nc]==player:
                cnt+=1; nr+=dr*sign; nc+=dc*sign
        if cnt >= 5:
            return True
    return False


def rule_score(board, r, c, player):
    """(r,c)에 player가 놨을 때 공격+방어 heuristic 점수."""
    n   = len(board)
    opp = 3 - player

    # 공격 점수
    board[r,c] = player
    atk = 0
    for dr, dc in DIRS:
        cnt, ends = count_consecutive(board, r, c, player, dr, dc)
        if cnt >= 5:            atk += SCORE_WIN
        elif cnt==4 and ends>=1: atk += SCORE_OPEN_FOUR
        elif cnt==3 and ends==2: atk += SCORE_OPEN_THREE
    center = n // 2
    atk += max(0, 6 - abs(r-center) - abs(c-center)) * SCORE_CENTER
    board[r,c] = 0

    # 방어 점수
    board[r,c] = opp
    dfn = 0
    for dr, dc in DIRS:
        cnt, ends = count_consecutive(board, r, c, opp, dr, dc)
        if cnt >= 5:            dfn += SCORE_BLOCK_WIN
        elif cnt==4 and ends>=1: dfn += SCORE_BLOCK_FOUR
        elif cnt==3 and ends==2: dfn += SCORE_BLOCK_THREE
    board[r,c] = 0

    return atk + dfn


# ──────────────────────────────────────────
# Minimax + Alpha-Beta
# ──────────────────────────────────────────

def heuristic_eval(board, player):
    opp   = 3 - player
    score = 0.0
    n     = len(board)
    score_table = {
        (5, 2): 100000, (5, 1): 100000,
        (4, 2): 10000,  (4, 1): 5000,
        (3, 2): 1000,   (3, 1): 200,
        (2, 2): 100,    (2, 1): 20,
    }

    for r in range(n):
        for c in range(n):
            if board[r,c] == player:
                for dr, dc in DIRS:
                    # 역방향에 같은 돌이 없을 때만 → 시작점 기준
                    pr, pc = r - dr, c - dc
                    if 0 <= pr < n and 0 <= pc < n and board[pr, pc] == player:
                        continue  # 이미 다른 칸에서 셈
                    cnt, ends = count_consecutive(board, r, c, player, dr, dc)
                    score += score_table.get((min(cnt, 5), ends), 0)
            elif board[r,c] == opp:
                for dr, dc in DIRS:
                    # 상대도 시작점 기준으로만 세어 중복 가산을 줄인다.
                    pr, pc = r - dr, c - dc
                    if 0 <= pr < n and 0 <= pc < n and board[pr, pc] == opp:
                        continue
                    cnt, ends = count_consecutive(board, r, c, opp, dr, dc)
                    score -= score_table.get((min(cnt, 5), ends), 0) * 1.1
    return score

def minimax(board, depth, alpha, beta, maximizing, player, last_move):
    INF = float('inf')
    opp = 3 - player

    if last_move is not None:
        r, c = last_move
        last_player = board[r, c]
        if last_player != 0 and check_win(board, r, c, last_player):
            return 100000.0 if last_player == player else -100000.0

    if depth == 0 or not np.any(board==0):
        return heuristic_eval(board, player)

    cands      = get_candidates(board, radius=2)
    cur_player = player if maximizing else opp
    cands.sort(key=lambda m: rule_score(board, m[0], m[1], cur_player),
               reverse=True)
    cands = cands[:8]

    if maximizing:
        best = -INF
        for r, c in cands:
            board[r,c] = player
            val        = minimax(board, depth-1, alpha, beta, False, player, (r,c))
            board[r,c] = 0
            best       = max(best, val)
            alpha      = max(alpha, best)
            if beta <= alpha: break
        return best
    else:
        best = INF
        for r, c in cands:
            board[r,c] = opp
            val        = minimax(board, depth-1, alpha, beta, True, player, (r,c))
            board[r,c] = 0
            best       = min(best, val)
            beta       = min(beta, best)
            if beta <= alpha: break
        return best


# ──────────────────────────────────────────
# Memory (기존 호환)
# ──────────────────────────────────────────

class Memory:
    def __init__(self):
        self.states   = []
        self.actions  = []
        self.logprobs = []
        self.values   = []
        self.rewards  = []
        self.dones    = []

    def clear(self):
        for lst in (self.states, self.actions, self.logprobs,
                    self.values, self.rewards, self.dones):
            lst.clear()

    def __len__(self):
        return len(self.rewards)


# ──────────────────────────────────────────
# HybridAgent (메인 에이전트)
# ──────────────────────────────────────────

class HybridAgent:
    # PPO 하이퍼파라미터
    LR           = 3e-4
    GAMMA        = 0.99
    GAE_LAMBDA   = 0.95
    CLIP_EPS     = 0.2
    ENTROPY_C    = 0.02
    VALUE_C      = 0.5
    EPOCHS       = 4
    BATCH_SIZE   = 32
    TRAIN_EVERY  = 5
    REWARD_SCALE = 0.02

    # Hybrid 설정
    TOP_K        = 8     # PPO 상위 후보 수
    SEARCH_DEPTH = 2     # Minimax 탐색 깊이

    def __init__(self, board_size: int = 15, player: int = 2):
        self.board_size  = board_size
        self.player      = player
        self.device      = torch.device(
            'cuda' if torch.cuda.is_available() else 'cpu')

        self.net     = PPOModel(board_size).to(self.device)
        self.old_net = PPOModel(board_size).to(self.device)
        self.old_net.load_state_dict(self.net.state_dict())
        self.old_net.eval()

        self.optimizer = torch.optim.Adam(
            self.net.parameters(), lr=self.LR)

        self.memory    = Memory()
        self.last_loss = None
        self._ep_count = 0

    # ── 착수 결정 (기존 인터페이스 유지)
    def decide_next_move(self, engine):
        board  = engine.board.board
        player = engine.current_player
        return self._hybrid_move(board, player)

    # ── 대국용 인터페이스 (play.py 호환)
    def get_move(self, board: np.ndarray, player: int):
        return self._hybrid_move(board, player)

    # ── 학습 중 빠른 착수 (PPO만 사용, Minimax 없음)
    def _ppo_only_move(self, engine):
        board  = engine.board.board
        player = engine.current_player
        opp    = 3 - player
        n      = self.board_size

        # state 생성
        ch1   = (board == player).astype(np.float32)
        ch2   = (board == opp).astype(np.float32)
        ch3   = np.ones((n,n), dtype=np.float32) if player==1 \
                else np.zeros((n,n), dtype=np.float32)
        state = np.stack([ch1, ch2, ch3], axis=0)

        state_t = torch.tensor(state, dtype=torch.float32)\
                      .unsqueeze(0).to(self.device)

        with torch.no_grad():
            probs, value = self.old_net(state_t)

        probs = probs.squeeze(0)
        value = value.item()

        # 유효 칸 마스킹
        mask = (board == 0).flatten()
        if player == 1:
            for idx in range(len(mask)):
                if mask[idx]:
                    r, c = divmod(idx, n)
                    if Rules.is_forbidden(board, r, c, 1):
                        mask[idx] = False

        mask_t = torch.tensor(mask, dtype=torch.bool, device=self.device)
        if not mask_t.any():
            return None

        probs = probs * mask_t.float()
        s     = probs.sum()
        probs = probs / s if s > 0 else mask_t.float() / mask_t.float().sum()

        dist   = Categorical(probs)
        action = dist.sample()

        # 메모리 저장
        self.memory.states.append(state)
        self.memory.actions.append(action.item())
        self.memory.logprobs.append(dist.log_prob(action).item())
        self.memory.values.append(value)

        row, col = divmod(action.item(), n)
        return (row, col)

    def _hybrid_move(self, board: np.ndarray, player: int):
        """하이브리드 착수 결정."""
        opp       = 3 - player
        cands     = get_candidates(board, radius=2)

        if not cands:
            return None

        # ── Step 1: 즉시 승리
        for r, c in cands:
            board[r,c] = player
            if check_win(board, r, c, player):
                board[r,c] = 0
                return (r, c)
            board[r,c] = 0

        # ── Step 2: 즉시 패배 방어
        for r, c in cands:
            board[r,c] = opp
            if check_win(board, r, c, opp):
                board[r,c] = 0
                return (r, c)
            board[r,c] = 0

        # ── Step 3: PPO top-K 후보 생성
        top_k = self._ppo_top_k(board, player, cands)

        # ── Step 4: Minimax로 최종 선택
        return self._minimax_select(board, player, top_k)

    def _ppo_top_k(self, board, player, cands):
        # 임시 state 생성
        opp  = 3 - player
        n    = self.board_size
        ch1  = (board == player).astype(np.float32)
        ch2  = (board == opp).astype(np.float32)
        ch3  = np.ones((n,n), dtype=np.float32) if player==1 \
               else np.zeros((n,n), dtype=np.float32)
        state = np.stack([ch1, ch2, ch3], axis=0)

        state_t = torch.tensor(state, dtype=torch.float32)\
                      .unsqueeze(0).to(self.device)

        with torch.no_grad():
            probs, _ = self.old_net(state_t)

        probs = probs.squeeze(0).cpu().numpy()

        # 후보 칸만 마스킹
        mask = np.zeros(n*n, dtype=bool)
        for r, c in cands:
            mask[r*n+c] = True

        probs = probs * mask.astype(float)
        s     = probs.sum()
        if s > 0:
            probs /= s
        else:
            probs = mask.astype(float) / mask.sum()

        # 상위 K개 인덱스
        top_idx = np.argsort(probs)[-self.TOP_K:][::-1]
        top_k   = [(int(idx//n), int(idx%n))
                   for idx in top_idx
                   if board[idx//n][idx%n] == 0]

        return top_k if top_k else cands[:self.TOP_K]

    def _minimax_select(self, board, player, candidates):
        INF        = float('inf')
        best_score = -INF
        best_move  = candidates[0]

        for r, c in candidates:
            board[r,c] = player
            score      = minimax(board, self.SEARCH_DEPTH-1,
                                 -INF, INF, False, player, (r,c))
            board[r,c] = 0
            if score > best_score:
                best_score = score
                best_move  = (r, c)

        return best_move

    # ── 보상 저장 + 학습 (학습 루프용)
    def store_reward(self, reward: float, done: bool = False):
        scaled = reward * self.REWARD_SCALE
        self.memory.rewards.append(scaled)
        self.memory.dones.append(done)

        if done:
            self._ep_count += 1
            if self._ep_count % self.TRAIN_EVERY == 0:
                self.last_loss = self._train()
                self.memory.clear()

    # ── 학습 루프용 state 저장
    def _store_state(self, engine):
        """decide_next_move 내부에서 호출 — state/action/logprob 저장."""
        pass  # store_reward와 분리하여 학습 루프에서 관리

    # ── PPO 학습
    def _train(self):
        T = min(len(self.memory.states), len(self.memory.rewards))
        if T < self.BATCH_SIZE:
            return self.last_loss

        states   = torch.tensor(np.array(self.memory.states[:T]),
                                dtype=torch.float32, device=self.device)
        actions  = torch.tensor(self.memory.actions[:T],
                                dtype=torch.long, device=self.device)
        old_lps  = torch.tensor(self.memory.logprobs[:T],
                                dtype=torch.float32, device=self.device)
        old_vals = torch.tensor(self.memory.values[:T],
                                dtype=torch.float32, device=self.device)
        rewards  = self.memory.rewards[:T]
        dones    = self.memory.dones[:T]

        advantages = self._gae(rewards, dones, old_vals)
        returns    = (advantages + old_vals).detach()
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        total_loss, count = 0.0, 0
        for _ in range(self.EPOCHS):
            idx = torch.randperm(T, device=self.device)
            for start in range(0, T, self.BATCH_SIZE):
                mb = idx[start: start + self.BATCH_SIZE]
                if len(mb) < 2:
                    continue
                loss = self._ppo_loss(
                    states[mb], actions[mb],
                    old_lps[mb], advantages[mb], returns[mb])
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), max_norm=0.5)
                self.optimizer.step()
                total_loss += loss.item()
                count      += 1

        self.old_net.load_state_dict(self.net.state_dict())
        return total_loss / max(count, 1)

    def _gae(self, rewards, dones, values):
        T    = len(rewards)
        advs = torch.zeros(T, device=self.device)
        gae  = 0.0
        for t in reversed(range(T)):
            nv    = values[t+1].item() if t+1 < T else 0.0
            delta = (rewards[t] + self.GAMMA * nv * (1-int(dones[t]))
                     - values[t].item())
            gae   = delta + self.GAMMA * self.GAE_LAMBDA * (1-int(dones[t])) * gae
            advs[t] = gae
        return advs

    def _ppo_loss(self, states, actions, old_log_probs, advantages, returns):
        probs, values = self.net(states)
        values        = values.squeeze(-1)
        dist          = Categorical(probs)
        log_probs     = dist.log_prob(actions)
        entropy       = dist.entropy().mean()

        ratio       = (log_probs - old_log_probs).exp()
        clip_ratio  = ratio.clamp(1-self.CLIP_EPS, 1+self.CLIP_EPS)
        policy_loss = -torch.min(ratio*advantages, clip_ratio*advantages).mean()
        value_loss  = F.mse_loss(values, returns)
        return policy_loss + self.VALUE_C*value_loss - self.ENTROPY_C*entropy

    # ── 가중치 관리
    def save(self, path: str = 'ppo_p2.pt'):
        torch.save({
            'net'      : self.net.state_dict(),
            'optimizer': self.optimizer.state_dict(),
        }, path)
        print(f'[HybridAgent] 저장 → {path}')

    def load(self, path: str = 'ppo_p2.pt'):
        if not os.path.exists(path):
            print(f'[HybridAgent] {path} 없음 — 랜덤 가중치로 시작')
            return
        ckpt = torch.load(path, map_location=self.device)
        self.net.load_state_dict(ckpt['net'])
        self.old_net.load_state_dict(ckpt['net'])
        self.optimizer.load_state_dict(ckpt['optimizer'])
        print(f'[HybridAgent] 로드 완료 ← {path}')

    def clone_weights(self):
        return {k: v.cpu().clone()
                for k, v in self.net.state_dict().items()}

    def make_champion_agent(self, weights):
        champ = HybridAgent(self.board_size, player=2)
        sd    = {k: v.to(self.device) for k, v in weights.items()}
        champ.net.load_state_dict(sd)
        champ.old_net.load_state_dict(sd)
        champ.old_net.eval()
        return champ

    def set_search_profile(self, top_k: int, search_depth: int):
        # 사람 대전용으로 탐색 강도를 동적으로 조절한다.
        self.TOP_K = max(4, int(top_k))
        self.SEARCH_DEPTH = max(1, int(search_depth))

# ── 하위 호환용 별칭
PPOAgent = HybridAgent