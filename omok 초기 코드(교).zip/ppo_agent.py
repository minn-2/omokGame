import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical
from model import PPOModel

class PPOAgent:
    def __init__(self, board_size, lr=3e-4, gamma=0.99, eps_clip=0.2):
        """
        <PPO 에이전트 초기화>
        :param lr: 학습률 (Learning Rate)
        :param gamma: 할인율 (Discount Factor) - 미래 보상을 얼마나 중요하게 여길지 결정
        :param eps_clip: PPO의 핵심인 Clipping 범위 - 급격한 정책 변화를 방지하여 안정성 확보
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.board_size = board_size
        self.gamma = gamma
        self.eps_clip = eps_clip
        
        # Policy (현재 학습 중인 정책)와 Policy_Old (비교 대상이 되는 이전 정책)
        # 두 개의 네트워크를 유지하여 확률 변화율(Ratio)을 계산


        self.policy = PPOModel(board_size).to(self.device)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=lr)
        self.policy_old = PPOModel(board_size).to(self.device)
        self.policy_old.load_state_dict(self.policy.state_dict())

        # Critic의 가치 예측 오차를 계산하기 위한 MSE 손실 함수
        self.MseLoss = nn.MSELoss()

    def select_action(self, state, valid_moves):
        """
        행동 선택: Exploration vs Exploitation
        현재상태에서 확률 분포를 생성하고 하나의 행동을 샘플링
        """
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            probs, _ = self.policy_old(state)

        # 액션 마스킹: 착수 불가능한 위치의 확률을 0으로 제거
        mask = torch.zeros(self.board_size * self.board_size).to(self.device)
        for m in valid_moves:
            mask[m[0] * self.board_size + m[1]] = 1
        
        masked_probs = probs.squeeze() * mask

        # 확률의 총합이 1이 되도록 정규화 (Re-normalization)
        if masked_probs.sum() > 0:
            masked_probs = masked_probs / masked_probs.sum()
        else:
            masked_probs = mask / mask.sum()

        # Categorical 분포를 통해 확률적으로 행동 선택 (다양한 수 읽기 학습 유도)
        dist = Categorical(masked_probs)
        action = dist.sample()
        return action.item(), dist.log_prob(action)

    def update(self, memory):
        """
        가중치 업데이트: PPO의 핵심 최적화 로직
        저장된 경험 데이터를 바탕으로 신경망을 훈련
        """

        # 메모리에서 데이터를 가져와 텐서로 변환
        states = torch.stack(memory.states).to(self.device).detach()
        actions = torch.stack(memory.actions).to(self.device).detach()
        logprobs = torch.stack(memory.logprobs).to(self.device).detach()
        rewards = torch.tensor(memory.rewards).to(self.device).detach().float()
        
        # 보상 정규화: 학습 안정성을 위해 보상의 평균과 표준편차를 활용해 스케일링
        if len(rewards) > 1:
            rewards = (rewards - rewards.mean()) / (rewards.std() + 1e-5)

        # 10 에포크 동안 반복 학습
        for _ in range(10):
            # 현재 정책에서의 확률분포 및 상태 가치 예측
            probs, state_values = self.policy(states)
            dist = Categorical(probs)
            new_logprobs = dist.log_prob(actions)
            entropy = dist.entropy() # 탐색의 다양성을 유지하기 위한 엔트로피
            
            # Ratio (rt): 이전 정책 대비 현재 정책의 확률 변화 비율
            ratios = torch.exp(new_logprobs - logprobs)

            # Advantage : 실제 보상과 예측 가치의 차이 (예상보다 얼마나 더 좋았는지)
            advantages = rewards - state_values.detach().squeeze()
            
            # PPO의 Clipped Objective Function 계산
            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1-self.eps_clip, 1+self.eps_clip) * advantages
            

            # 최종 손실 함수 = -정책손실(Clipped) + 가치손실(MSE) - 엔트로피 보너스
            # 1. 정책 손실: 좋은 행동의 확률은 높이되 과도한 변화는 Clip함
            # 2. 가치 손실: 판세를 정확히 읽도록 Critic 학습 (계수 0.5)
            # 3. 엔트로피: AI가 너무 일찍 한 가지 수에 매몰되지 않도록 유도 (계수 0.01)
            loss = -torch.min(surr1, surr2) + 0.5 * self.MseLoss(state_values.squeeze(), rewards) - 0.01 * entropy
            
            # 역전파 및 가중치 업데이트
            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()
        
        # 학습된 정책을 다시 policy_old로 복사하여 다음 에피소드 준비
        self.policy_old.load_state_dict(self.policy.state_dict())
        return loss.mean().item()

class Memory:
    """
    경험 재생 버퍼
    한 에피소드 동안 발생한 상태, 행동, 로그 확률, 보상을 저장하는 컨테이너
    """
    def __init__(self):
        self.states, self.actions, self.logprobs, self.rewards = [], [], [], []
    def clear(self):
        self.states.clear(); self.actions.clear(); self.logprobs.clear(); self.rewards.clear()