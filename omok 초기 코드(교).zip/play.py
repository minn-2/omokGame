import os
# pyTorch와 라이브러리 간 충돌로 발생하는 실행 에러를 방지하기 위한 환경 변수 설정
os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

import torch
import pygame
import sys
import numpy as np
from engine import OmokEngine
from model import PPOModel

#  UI CONSTANTS: 고정된 디자인 수치 (하드코딩 방지를 위한 상수화)
BOARD_SIZE = 10
CELL_SIZE = 60
SIDEBAR_WIDTH = 250
PADDING = 60
SCREEN_WIDTH = (BOARD_SIZE * CELL_SIZE) + PADDING + SIDEBAR_WIDTH
SCREEN_HEIGHT = (BOARD_SIZE * CELL_SIZE) + PADDING
# 색상 값 정의 (RGB 포맷)
COLOR_BG = (28, 28, 38)
COLOR_SIDEBAR = (35, 35, 50)
COLOR_BOARD = (210, 170, 110)
COLOR_GRID = (45, 45, 55)
COLOR_ACCENT = (0, 255, 200)

class ModernOmok:
    def __init__(self):
        """
        시스템 초기화: Pygame GUI 설정 및 훈련된 AI 모델 로드
        """
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("OMOK - SANKALPA EDITION")
        # 폰트 로드: 세련된 UI를 위해 Segoe UI 사용
        self.font_m = pygame.font.SysFont("Segoe UI", 28, bold=True)
        self.font_s = pygame.font.SysFont("Segoe UI", 18)
        self.clock = pygame.time.Clock()
        
        # 하드웨어 가속: GPU(CUDA) 사용 가능 여부 확인 후 장치 할당
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # AI 모델 인스턴스화 및 장치로 전송 (CPU/GPU)
        self.model = PPOModel(BOARD_SIZE).to(self.device)
        self.load_model()
        self.reset_game()

    def load_model(self):
        """
        가중치 로드: 훈련된 .pth 파일(Model Weight)을 신경망에 주입
        """
        model_path = "ppo_omok_reward.pth"
        if os.path.exists(model_path):
            # map_location: GPU에서 학습한 모델을 CPU에서 실행할 때 생기는 충돌 방지
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))
            self.model.eval() # 추론 모드 전환 (Dropout이나 Batch Norm 비활성화)
            self.model_status = "LOADED"
        else:
            # 모델 파일이 없으면 학습 안 된 랜덤 상태로 게임 진행
            self.model_status = "RANDOM MODE"

    def reset_game(self):
        """
        게임 상태 초기화: 엔진 인스턴스를 새로 생성
        """
        self.env = OmokEngine(BOARD_SIZE)
        self.last_move = None
        self.game_over_fade = 0

    def draw_glass_rect(self, rect, color, alpha):
        """
        그래픽 기술: 투명도가 포함된 레이어를 그리기 위한 함수
        """

        s = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        s.fill((*color, alpha))
        self.screen.blit(s, (rect.x, rect.y))

    def draw(self):
        """
        렌더링 루프: 보드, 돌, 사이드바, 게임 종료 화면을 프레임마다 그림
        """
        self.screen.fill(COLOR_BG)
        
        # 사이드바 및 상태 표시
        pygame.draw.rect(self.screen, COLOR_SIDEBAR, (SCREEN_WIDTH - SIDEBAR_WIDTH, 0, SIDEBAR_WIDTH, SCREEN_HEIGHT))
        self.screen.blit(self.font_m.render("OMOK", True, COLOR_ACCENT), (SCREEN_WIDTH - SIDEBAR_WIDTH + 30, 40))
        self.screen.blit(self.font_s.render(f"STATUS: {self.model_status}", True, (150, 150, 150)), (SCREEN_WIDTH - SIDEBAR_WIDTH + 30, 80))
        
        # 턴 안내: 현재 플레이어가 누구인지 표시
        turn_txt = "YOUR TURN" if self.env.current_player == 1 else "AI THINKING..."
        turn_clr = (255, 255, 255) if self.env.current_player == 1 else COLOR_ACCENT
        self.screen.blit(self.font_s.render(turn_txt, True, turn_clr), (SCREEN_WIDTH - SIDEBAR_WIDTH + 30, 150))

        # Instructions
        self.screen.blit(self.font_s.render("PRESS 'R' TO RESTART", True, (100, 100, 100)), (SCREEN_WIDTH - SIDEBAR_WIDTH + 30, SCREEN_HEIGHT - 60))

        # 보드 드로잉
        board_rect = pygame.Rect(PADDING//2, PADDING//2, BOARD_SIZE*CELL_SIZE, BOARD_SIZE*CELL_SIZE)
        pygame.draw.rect(self.screen, COLOR_BOARD, board_rect, border_radius=10)
        

        #격자선 그리기 (Grid)
        for i in range(BOARD_SIZE):
            pygame.draw.line(self.screen, COLOR_GRID, (PADDING, PADDING + i*CELL_SIZE), (BOARD_SIZE*CELL_SIZE, PADDING + i*CELL_SIZE), 1)
            pygame.draw.line(self.screen, COLOR_GRID, (PADDING + i*CELL_SIZE, PADDING), (PADDING + i*CELL_SIZE, BOARD_SIZE*CELL_SIZE), 1)

        # 돌 드로잉: 입체감 있는 렌더링
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                pos = (PADDING + c * CELL_SIZE, PADDING + r * CELL_SIZE)
                if self.env.board[r, c] == 1: # Black
                    pygame.draw.circle(self.screen, (20, 20, 25), (pos[0]+2, pos[1]+2), 22) # Shadow
                    pygame.draw.circle(self.screen, (10, 10, 15), pos, 22)
                    pygame.draw.circle(self.screen, (60, 60, 70), (pos[0]-6, pos[1]-6), 6)
                elif self.env.board[r, c] == 2: # White
                    pygame.draw.circle(self.screen, (150, 150, 160), (pos[0]+2, pos[1]+2), 22) # Shadow
                    pygame.draw.circle(self.screen, (240, 240, 250), pos, 22)
                    pygame.draw.circle(self.screen, (255, 255, 255), (pos[0]-6, pos[1]-6), 7)

         # 마지막 착수 지점 표시 (직관적인 게임 플레이 도움)
        if self.last_move:
            pygame.draw.circle(self.screen, (255, 50, 50), (PADDING + self.last_move[1]*CELL_SIZE, PADDING + self.last_move[0]*CELL_SIZE), 6)

        # 게임 오버 오버레이 (Alpha Blending 사용)
        if self.env.is_over:
            self.draw_glass_rect(pygame.Rect(0,0, SCREEN_WIDTH, SCREEN_HEIGHT), (0,0,0), 180)
            msg = "VICTORY!" if self.env.winner == 1 else "DEFEAT!" if self.env.winner == 2 else "DRAW"
            color = (0, 255, 150) if self.env.winner == 1 else (255, 80, 80)
            txt = self.font_m.render(msg, True, color)
            self.screen.blit(txt, (SCREEN_WIDTH//2 - txt.get_width()//2 - 100, SCREEN_HEIGHT//2 - 20))
            sub_txt = self.font_s.render("PRESS 'R' TO PLAY AGAIN", True, (200, 200, 200))
            self.screen.blit(sub_txt, (SCREEN_WIDTH//2 - sub_txt.get_width()//2 - 100, SCREEN_HEIGHT//2 + 30))

    def run(self):
        """
        메인 이벤트 루프:사용자 입력 처리 및 AI 추론 연산 실행
        """
        while True:
            self.draw()
            pygame.display.flip()
            
            if not self.env.is_over:
                if self.env.current_player == 1:
                    #  사용자(사람)의 차례
                    for event in pygame.event.get():
                        if event.type == pygame.QUIT: pygame.quit(); sys.exit()
                        if event.type == pygame.KEYDOWN and event.key == pygame.K_r: self.reset_game()
                        if event.type == pygame.MOUSEBUTTONDOWN:
                            mx, my = pygame.mouse.get_pos()
                            # 클릭 좌표를 보드 인덱스(0~9)로 정규화
                            c, r = round((mx-PADDING)/CELL_SIZE), round((my-PADDING)/CELL_SIZE)
                            if 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE:
                                if self.env.make_move(r, c): self.last_move = (r, c)
                else:
                    # AI의 차례
                    pygame.time.wait(600)  # AI가 생각하는 듯한 효과를 위함

                    # 1. 현재 보드 상태를 텐서로 변환 후 모델 입력 포맷에 맞춤 (unsqueeze로 배치 차원 추가)
                    state = torch.FloatTensor(self.env.get_state()).unsqueeze(0).to(self.device)

                    # 2. 신경망 추론 (Inference): 가중치 업데이트가 필요 없어서 no_grad() 사용
                    with torch.no_grad(): probs, _ = self.model(state)

                    # 3. 액션 마스킹: 이미 돌이 놓인 곳의 확률을 0으로 만들어 무효한 수를 방지
                    mask = torch.zeros(BOARD_SIZE * BOARD_SIZE).to(self.device)
                    for m in self.env.get_valid_moves(): mask[m[0]*BOARD_SIZE + m[1]] = 1

                    # 유효한 칸의 확률만 남기고 나머지는 필터링
                    probs = probs.squeeze() * mask

                    # 4. 결정: 확률이 가장 높은 곳(argmax)을 선택, 유효한 수가 없으면 랜덤 선택
                    action = torch.argmax(probs).item() if probs.sum() > 0 else np.random.choice([m[0]*BOARD_SIZE + m[1] for m in self.env.get_valid_moves()])

                    # 5. 1차원 인덱스를 2차원(r, c) 좌표로 복원 후 착수
                    r, c = divmod(action, BOARD_SIZE)
                    self.env.make_move(r, c)
                    self.last_move = (r, c)
            else:
                # 게임 종료 후 대기 이벤트 처리
                for event in pygame.event.get():
                    if event.type == pygame.QUIT: pygame.quit(); sys.exit()
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_r: self.reset_game()
            
            self.clock.tick(60) # 60 FPS 유지

    def resource_path(relative_path):
        """
        배포용 설정: PyInstaller로 패키징할 때 모델 파일의 경로를 절대 경로로 반환
        """
        try:
            
            base_path = sys._MEIPASS # 임시 폴더 경로
        except Exception:
            base_path = os.path.abspath(".")
        return os.path.join(base_path, relative_path)


    model_file_path = resource_path("ppo_omok_reward.pth")

if __name__ == "__main__":
    ModernOmok().run()