import torch
import torch.nn as nn
import torch.nn.functional as F

class PPOModel(nn.Module):
    def __init__(self, board_size):
        """
        심층 강화 학습 모델 설계
        Actor-Critic 구조를 활용해서 정책(Action)과 가치(Value)를 동시에 학습
        """
        super(PPOModel, self).__init__()
        self.board_size = board_size
        
        # Convolutional Block: 특징 추출기
        # 오목판의 국소적인 패턴(3x3영역) 스캔해서 "모양"인식
        self.conv_block = nn.Sequential(
            # 1. layer: 입력 채널 1(보드 상황)에서 64개의 특징 지도 생성
            nn.Conv2d(1, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            
            # 2. layer: 64개 특징 조합해서 더 복잡한 형태(4목, 3목 등)을 인식
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            
            # 3. layer: 고차원적인 전술적 특징을 추출해서 데이터로 추상화
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.ReLU()
        )
        
        # 수학적 계산 Flatten Size: COnv 출력(128채널)* 보드너비 * 보드높이
        # CNN의 3D출력을 1D 벡터로 펼처서 Fully Connected(Linear)층으로 전달하기 위한 크기 
        self.flatten_size = 128 * board_size * board_size
        
        # Actor Head: 정책 결정기 
        # 현재 상태에서 각 칸에 돌을 놓을 확률 계산
        self.actor = nn.Sequential(
            nn.Linear(self.flatten_size, 256), #추출된 특징을 기반으로 고차원 추론 
            nn.ReLU(),
            
            # 보드 전체 칸수만큼 결과값 출력(10x10이면 100개 출력)
            nn.Linear(256, board_size * board_size)
        )
        
        #  Critic Head: 가치 평가기
        # 현재 보드 상황의 승률을 -1(패배 예상)~1(승리 예상) 사이로 평가
        self.critic = nn.Sequential(
            nn.Linear(self.flatten_size, 256),
            nn.ReLU(),
        
            # 결과값은 단 하나(Scalar): 현재 상태의 총체적 가치 점수
            nn.Linear(256, 1)
        )

    def forward(self, x):
        """
        입력된 보드 데이터를 해석하여 확률 분포와 가치 점수를 반환
        """
        # 1. CNN 층을 통과시키며 오목판의 시각적 특징 추출
        x = self.conv_block(x)
        
        # 2. D 텐서(Batch, C, H, W)를 1D(Batch, Features)로 변환 (Flatten)
        # view(x.size(0), -1)은 배치 크기는 유지하되 나머지 차원을 하나로 합치는 기법
        x = x.view(x.size(0), -1) 
        
        # 3. Actor 연산: Softmax를 취해 모든 출력값의 합이 1.0이 되도록 확률화
        # 이 확률을 보고 AI가 가장 높은 곳 혹은 전략적 위치를 선택함
        logits = self.actor(x)
        probs = F.softmax(logits, dim=-1) # All probabilities will sum to 1.0
        
        # 4. Critic 연산: 현재 보드 상황에 대한 단일 예측 가치 반환
        value = self.critic(x)
        
        return probs, value