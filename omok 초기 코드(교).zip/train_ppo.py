import torch
import pygame
import sys
import os
import numpy as np
from engine import OmokEngine
from ppo_agent import PPOAgent, Memory

#  UI COLORS 
COLOR_BG = (15, 15, 25)      # Deep Dark Blue/Black
COLOR_BOARD = (40, 40, 60)   # Modern Grid Gray
COLOR_ACCENT = (0, 255, 200) # Cyberpunk Cyan
COLOR_LOSS = (255, 80, 80)   # Soft Red
COLOR_REWARD = (100, 255, 100)# Lime Green
COLOR_TEXT = (220, 220, 220)

def get_shaped_reward(env, player):
    """
   Reward Shaping: 보상 형성 알고리즘
    Sparse Reward(게임 끝에만 보상을 주는 것)의 한계를 극복하기 위해 
    게임 중간에 '도움이 되는 행동'에 즉각적인 보상을 설계
    """
    # 1. Terminal Rewards (에피소드 종결 보상)
    if env.is_over:
        if env.winner == player: return 50.0      # 승리 시 큰 보상(최종 목표)
        if env.winner == (3 - player): return -50.0 # 패배 시 큰 패널티
        return 0.0                               # 무승부

    reward = 0.0
    opp = 3 - player
    
    # 2. Heuristic Pattern-based Rewards (휴리스틱 기반 중간 보상)
    # AI가 '수읽기'의 중요도를 깨닫도록 가중치를 차등 부여

    # 4목 체크: 승리 직전이므로 매우 높은 우선순위
    if env.check_patterns(player, 4): reward += 8.0
    # 상대방의 4목 방어: 방어 실패 시 즉시 패배하므로 가장 큰 패널티
    if env.check_patterns(opp, 4): reward -= 15.0 
    
   # 3목 체크: 전술적 우위를 점하기 위한 중급 보상
    if env.check_patterns(player, 3): reward += 3.0
    if env.check_patterns(opp, 3): reward -= 5.0
    
    return reward

def train_beast():
    """
    [Main Training Loop with Visualization]
    Pygame 렌더링과 신경망 학습을 병렬로 처리하는 메인 루프
    """
    # 환경 및 스크린 설정
    BOARD_SIZE = 10
    CELL_SIZE = 45
    SIDEBAR_WIDTH = 280
    PADDING = 40
    
    BOARD_SCREEN_SIZE = BOARD_SIZE * CELL_SIZE + PADDING * 2
    SCREEN_WIDTH = BOARD_SCREEN_SIZE + SIDEBAR_WIDTH
    SCREEN_HEIGHT = BOARD_SCREEN_SIZE

    # Pygame 엔진 및 폰트 객체 초기화
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("BEAST MODE TRAINING")
    
    font_s = pygame.font.SysFont("Segoe UI", 18)
    font_m = pygame.font.SysFont("Segoe UI", 28, bold=True)
    font_l = pygame.font.SysFont("Segoe UI", 45, bold=True)

   # 에이전트 및 메모리 버퍼 할당
    env = OmokEngine(BOARD_SIZE)
    agent = PPOAgent(BOARD_SIZE)
    memory = Memory()
    
   # 학습 모니터링 변수
    update_timestep = 2000 # 2000 걸음마다 신경망 업데이트 (Batch Size 개념)
    timestep = 0
    current_loss = 0.0
    last_ep_reward = 0.0
    
    print(f"BEAST MODE TRAINING STARTED ON: {agent.device}")

    # 10만 에피소드 시작
    for ep in range(1, 100001):
        state = env.reset() #매 게임마다 보드 초기화
        done = False
        ep_reward_accumulated = 0
        
        while not done:
           # GUI 이벤트 처리 (학습 중 창 닫기 등)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit(); sys.exit()

            timestep += 1
            
           # [ 1: Action Selection] AI의 현재 정책에 따른 착수 위치 결정
            valid_moves = env.get_valid_moves()
            action_idx, logprob = agent.select_action(state, valid_moves)
            
           # [ 2: Environment Interaction] 1차원 액션을 2차원 보드 좌표로 맵핑
            r, c = divmod(action_idx, BOARD_SIZE)
            env.make_move(r, c)
            
            # [ 3: Reward Calculation] Shaped Reward 함수를 호출해 즉각적인 피드백 생성
            step_reward = get_shaped_reward(env, 1) # 1번 플레이어(AI) 관점
            ep_reward_accumulated += step_reward

           #  [ 4: Real-time Rendering] 학습 과정 시각화 
            screen.fill(COLOR_BG)
            
           # 보드 격자 그리기
            pygame.draw.rect(screen, (25, 25, 35), (PADDING, PADDING, BOARD_SIZE*CELL_SIZE, BOARD_SIZE*CELL_SIZE))
            for i in range(BOARD_SIZE):
                # Vertical and Horizontal lines
                pygame.draw.line(screen, (45, 45, 60), (PADDING + i*CELL_SIZE, PADDING), (PADDING + i*CELL_SIZE, BOARD_SCREEN_SIZE-PADDING))
                pygame.draw.line(screen, (45, 45, 60), (PADDING, PADDING + i*CELL_SIZE), (BOARD_SCREEN_SIZE-PADDING, PADDING + i*CELL_SIZE))

           # 돌 그리기: 흑돌은 사이언 글로우 효과를 주어 'Beast Mode' 느낌 강조
            for rr in range(BOARD_SIZE):
                for cc in range(BOARD_SIZE):
                    if env.board[rr, cc] == 1:
                        pygame.draw.circle(screen, (0, 0, 0), (PADDING + cc*CELL_SIZE, PADDING + rr*CELL_SIZE), 18)
                        pygame.draw.circle(screen, COLOR_ACCENT, (PADDING + cc*CELL_SIZE, PADDING + rr*CELL_SIZE), 18, 2)
                    elif env.board[rr, cc] == 2:
                        pygame.draw.circle(screen, (255, 255, 255), (PADDING + cc*CELL_SIZE, PADDING + rr*CELL_SIZE), 18)

            # 사이드바 스탯 대시보드 
            sx = BOARD_SCREEN_SIZE + 20
            screen.blit(font_l.render("OMOK", True, COLOR_ACCENT), (sx, 40))
            screen.blit(font_s.render("BEAST MODE ACTIVE", True, (150, 150, 150)), (sx, 95))

            # Helper function to display text stats
            def draw_stat(label, value, y, color):
                screen.blit(font_s.render(label, True, COLOR_TEXT), (sx, y))
                screen.blit(font_m.render(str(value), True, color), (sx, y + 25))

            draw_stat("EPISODE", f"{ep:,}", 150, COLOR_TEXT)
            draw_stat("CURRENT LOSS", f"{current_loss:.6f}", 240, COLOR_LOSS)
            draw_stat("LAST EP REWARD", f"{last_ep_reward:.1f}", 330, COLOR_REWARD)
            
            # 최적화 진행률 바 (Optimization Progress Bar)
            pygame.draw.rect(screen, (40, 40, 50), (sx, 450, 220, 10))
            progress = (timestep / update_timestep) * 220
            pygame.draw.rect(screen, COLOR_ACCENT, (sx, 450, progress, 10))
            screen.blit(font_s.render("OPTIMIZATION PROGRESS", True, (100, 100, 100)), (sx, 465))

            pygame.display.flip() # 더블 버퍼링 업데이트

            # [5: Memory Storage] On-policy 학습을 위한 궤적 데이터 저장
            # Save the experience to the memory buffer for later training
            memory.states.append(torch.FloatTensor(state))
            memory.actions.append(torch.tensor(action_idx))
            memory.logprobs.append(logprob)
            memory.rewards.append(step_reward)
            
            state = env.get_state()
            done = env.is_over
            
           # [ 6: Policy Update] 데이터가 충분히 쌓이면 PPO 업데이트 실행
            
            if timestep % update_timestep == 0:
                loss_val = agent.update(memory)
                if loss_val: current_loss = loss_val
                memory.clear()# 다음 업데이트를 위해 메모리 초기화
                timestep = 0
        
        last_ep_reward = ep_reward_accumulated
        
       # 주기적 모델 저장 및 로그 출력
        if ep % 100 == 0:
            print(f"Ep: {ep:6d} | Loss: {current_loss:.6f} | Reward: {last_ep_reward:.1f}")
            # Save the "Brain" of the AI to a file
            torch.save(agent.policy.state_dict(), "ppo_omok_reward.pth")

if __name__ == "__main__":
    train_beast()